package com.aiswarm.mobile

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

private data class ProviderSpec(
    val id: String,
    val title: String,
    val kind: String,
    val endpoint: String,
    val model: String,
    val description: String
)

private data class ProviderConfig(
    val spec: ProviderSpec,
    val endpoint: String,
    val model: String,
    val apiKey: String
)

class MainActivity : Activity() {
    private val providers = listOf(
        ProviderSpec("gemini", "Google Gemini", "gemini", "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", "gemini-3.8-flash", "Gemini API • obsługuje systemInstruction"),
        ProviderSpec("groq", "Groq", "openai", "https://api.groq.com/openai/v1/chat/completions", "openai/gpt-oss-120b", "OpenAI-compatible • dostępność modeli zależy od konta"),
        ProviderSpec("deepseek", "DeepSeek", "openai", "https://api.deepseek.com/chat/completions", "deepseek-flash", "OpenAI-compatible • osobny klucz API"),
        ProviderSpec("openai", "OpenAI", "openai", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", "OpenAI API • klucz API nie jest kontem ChatGPT"),
        ProviderSpec("claude", "Anthropic Claude", "anthropic", "https://api.anthropic.com/v1/messages", "claude-haiku-4-5-20251001", "Anthropic Messages API"),
        ProviderSpec("grok", "xAI Grok", "openai", "https://api.x.ai/v1/chat/completions", "grok-4.7", "OpenAI-compatible • osobny klucz API")
    )

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var store: SecureStore
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var taskInput: EditText
    private lateinit var projectInput: EditText
    private var currentPage = "home"
    private var busy = false
    private var lastOutput = ""
    private var lastTask = ""
    private var liveStatus: TextView? = null
    private var runButton: TextView? = null
    private val agentRoles = listOf(
        Triple("manager", "Manager / Planista", "Rozbija zadanie na etapy i kryteria ukończenia."),
        Triple("research", "Research / Analityk", "Analizuje wymagania, założenia i ryzyka. Bez automatycznego przeglądania internetu."),
        Triple("builder", "Builder / Wykonawca", "Tworzy właściwy rezultat: kod, stronę, bot lub dokumentację."),
        Triple("reviewer", "Reviewer / Tester", "Sprawdza wynik, wykrywa braki i przygotowuje finalną wersję.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("aiswarm", Context.MODE_PRIVATE)
        store = SecureStore(this)
        renderPage("home")
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 16, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun label(value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
        setTextIsSelectable(true)
    }

    private fun addLabel(parent: LinearLayout, value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) {
        parent.addView(label(value, size, color, bold), LinearLayout.LayoutParams(-1, -2))
    }

    private fun gap(parent: LinearLayout, height: Int = 10) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun card(parent: LinearLayout, pad: Int = 16): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            background = rounded(Color.rgb(27, 33, 49), 18, Color.rgb(49, 59, 82))
        }
        parent.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        return box
    }

    private fun actionButton(parent: LinearLayout, title: String, primary: Boolean = false, action: () -> Unit): TextView {
        val color = if (primary) Color.rgb(85, 112, 245) else Color.rgb(42, 51, 72)
        val button = TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = rounded(color, 13)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        return button
    }

    private fun field(hint: String, multiline: Boolean = false, password: Boolean = false, value: String = ""): EditText = EditText(this).apply {
        setText(value)
        this.hint = hint
        textSize = 14f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(145, 154, 174))
        setPadding(dp(13), dp(11), dp(13), dp(11))
        background = rounded(Color.rgb(17, 22, 35), 12, Color.rgb(66, 76, 101))
        if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        else if (multiline) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        else inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (multiline) { minLines = 4; maxLines = 10; gravity = Gravity.TOP }
        else { minLines = 1; maxLines = 3 }
    }

    private fun renderPage(page: String) {
        currentPage = page
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 16, 27))
            setPadding(dp(15), dp(12), dp(15), dp(10))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "AI SWARM"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val connected = providers.count { store.loadConfig(it.id)?.apiKey?.isNotBlank() == true }
        top.addView(label("$connected/${providers.size} API", 12f, Color.rgb(154, 171, 207), true))
        root.addView(top)
        addLabel(root, "Zespół AI na Androida • wersja 1.0", 12f, Color.rgb(145, 154, 174))

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(10)) }
        val tabs = listOf("home" to "Start", "team" to "Agenci", "providers" to "API", "history" to "Historia", "links" to "Narzędzia")
        tabs.forEach { (id, title) ->
            val selected = page == id
            val item = TextView(this).apply {
                text = title
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(if (selected) Color.WHITE else Color.rgb(166, 176, 198))
                setPadding(dp(7), dp(10), dp(7), dp(10))
                background = if (selected) rounded(Color.rgb(53, 69, 111), 10) else rounded(Color.TRANSPARENT, 10)
                setOnClickListener { renderPage(id) }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(3) })
        }
        root.addView(nav)
        val line = View(this).apply { setBackgroundColor(Color.rgb(43, 52, 72)) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)))

        scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(13), 0, dp(18)) }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        when (page) {
            "home" -> renderHome()
            "team" -> renderTeam()
            "providers" -> renderProviders()
            "history" -> renderHistory()
            "links" -> renderLinks()
            "result" -> renderResult()
        }
        setContentView(root)
    }

    private fun renderHome() {
        val hero = card(body)
        addLabel(hero, "Od pomysłu do gotowego projektu", 21f, Color.WHITE, true)
        gap(hero, 4)
        addLabel(hero, "Uruchom 4 role AI kolejno. Każda rola przekazuje wynik następnej, a Reviewer sprawdza końcowy rezultat.", 13f, Color.rgb(186, 197, 218))
        gap(hero, 12)
        addLabel(hero, "NAZWA PROJEKTU", 11f, Color.rgb(146, 164, 204), true)
        projectInput = field("Np. Moja strona / bot Discord")
        hero.addView(projectInput, LinearLayout.LayoutParams(-1, -2))
        gap(hero, 10)
        addLabel(hero, "CO ZESPÓŁ MA ZROBIĆ?", 11f, Color.rgb(146, 164, 204), true)
        taskInput = field("Opisz dokładnie cel, funkcje, wygląd i ograniczenia...", true)
        hero.addView(taskInput, LinearLayout.LayoutParams(-1, -2))
        gap(hero, 10)
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val website = smallButton("Strona WWW") { taskInput.setText("Stwórz kompletną, nowoczesną, responsywną stronę WWW. Przygotuj pełny kod HTML, CSS i JavaScript, strukturę plików, instrukcję uruchomienia oraz testy.") }
        val discord = smallButton("Bot Discord") { taskInput.setText("Zaprojektuj i napisz działającego bota Discord. Przygotuj kompletny kod, strukturę projektu, listę wymaganych uprawnień, konfigurację przez zmienne środowiskowe i instrukcję uruchomienia.") }
        presets.addView(website, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        presets.addView(discord, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(presets)
        gap(hero, 10)
        runButton = actionButton(hero, "URUCHOM ZESPÓŁ AI", true) { startSwarm() }
        liveStatus = label("Gotowy. Dodaj klucz API w zakładce API, aby uruchomić agentów.", 12f, Color.rgb(163, 181, 212))
        hero.addView(liveStatus)

        val info = card(body)
        addLabel(info, "Jak działa Swarm", 16f, Color.WHITE, true)
        agentRoles.forEachIndexed { i, role ->
            gap(info, 4)
            addLabel(info, "${i + 1}. ${role.second}", 13f, Color.rgb(221, 229, 246), true)
            addLabel(info, role.third, 12f, Color.rgb(156, 169, 194))
        }
        gap(info, 8)
        addLabel(info, "Research analizuje wiedzę modelu i materiały, które wpiszesz. Ta wersja nie udaje automatycznej wyszukiwarki internetowej.", 11f, Color.rgb(242, 199, 122))

        val quick = card(body)
        addLabel(quick, "Szybki dostęp", 15f, Color.WHITE, true)
        actionButton(quick, "Ustaw klucze API i modele") { renderPage("providers") }
        actionButton(quick, "Skonfiguruj role agentów") { renderPage("team") }
    }

    private fun smallButton(title: String, action: () -> Unit): TextView = TextView(this).apply {
        text = title
        gravity = Gravity.CENTER
        textSize = 12f
        setTextColor(Color.WHITE)
        setPadding(dp(7), dp(10), dp(7), dp(10))
        background = rounded(Color.rgb(45, 57, 84), 10)
        setOnClickListener { action() }
    }

    private fun renderTeam() {
        val intro = card(body)
        addLabel(intro, "Konfiguracja zespołu", 20f, Color.WHITE, true)
        addLabel(intro, "Wybierz osobny model dla każdej roli. Gdy wybrany dostawca nie ma klucza, aplikacja użyje pierwszego skonfigurowanego dostawcy.", 13f, Color.rgb(179, 190, 212))
        agentRoles.forEach { (id, title, description) ->
            val c = card(body, 14)
            addLabel(c, title, 15f, Color.WHITE, true)
            addLabel(c, description, 12f, Color.rgb(162, 175, 201))
            gap(c, 6)
            val spinner = Spinner(this)
            val names = providers.map { it.title }
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            val savedId = prefs.getString("role.$id", providers.first().id) ?: providers.first().id
            spinner.setSelection(providers.indexOfFirst { it.id == savedId }.coerceAtLeast(0))
            c.addView(spinner, LinearLayout.LayoutParams(-1, -2))
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, itemId: Long) {
                    prefs.edit().putString("role.$id", providers[position].id).apply()
                }
            }
        }
        val note = card(body)
        addLabel(note, "Ważne", 14f, Color.rgb(241, 197, 119), true)
        addLabel(note, "To są prawdziwe wywołania API dostawców, nie automatyczne klikanie w darmowe strony ChatGPT/Claude. Każdy dostawca może naliczać opłaty i mieć własne limity.", 12f, Color.rgb(183, 193, 211))
    }

    private fun renderProviders() {
        val intro = card(body)
        addLabel(intro, "Dostawcy AI / klucze API", 20f, Color.WHITE, true)
        addLabel(intro, "Wklej własny klucz API i model z panelu danego dostawcy. Klucz jest szyfrowany w pamięci aplikacji przez Android Keystore. Nie wpisuj tu hasła do konta ani ciasteczek.", 12f, Color.rgb(181, 192, 215))
        providers.forEach { spec ->
            val config = store.loadConfig(spec.id)
            val c = card(body, 14)
            addLabel(c, spec.title, 16f, Color.WHITE, true)
            addLabel(c, spec.description, 11f, Color.rgb(157, 172, 199))
            val endpoint = field("Adres API", value = config?.endpoint ?: spec.endpoint)
            val model = field("Nazwa modelu", value = config?.model ?: spec.model)
            val key = field(if (config?.apiKey?.isNotBlank() == true) "Nowy klucz (puste = zachowaj zapisany)" else "Wklej klucz API", password = true)
            gap(c, 8)
            addLabel(c, "ENDPOINT", 10f, Color.rgb(140, 157, 190), true)
            c.addView(endpoint, LinearLayout.LayoutParams(-1, -2))
            gap(c, 7)
            addLabel(c, "MODEL", 10f, Color.rgb(140, 157, 190), true)
            c.addView(model, LinearLayout.LayoutParams(-1, -2))
            gap(c, 7)
            addLabel(c, "KLUCZ API", 10f, Color.rgb(140, 157, 190), true)
            c.addView(key, LinearLayout.LayoutParams(-1, -2))
            gap(c, 8)
            val savedStatus = label(if (config?.apiKey?.isNotBlank() == true) "● Klucz zapisany lokalnie" else "○ Brak klucza", 11f, if (config?.apiKey?.isNotBlank() == true) Color.rgb(119, 220, 165) else Color.rgb(235, 181, 117))
            c.addView(savedStatus)
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val save = smallButton("Zapisz") {
                store.saveConfig(spec.id, endpoint.text.toString().trim(), model.text.toString().trim(), key.text.toString())
                key.setText("")
                savedStatus.text = if (store.loadConfig(spec.id)?.apiKey?.isNotBlank() == true) "● Klucz zapisany lokalnie" else "○ Brak klucza"
                savedStatus.setTextColor(if (store.loadConfig(spec.id)?.apiKey?.isNotBlank() == true) Color.rgb(119, 220, 165) else Color.rgb(235, 181, 117))
                Toast.makeText(this, "Zapisano ustawienia ${spec.title}", Toast.LENGTH_SHORT).show()
            }
            buttons.addView(save, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
            val test = smallButton("Test API") {
                store.saveConfig(spec.id, endpoint.text.toString().trim(), model.text.toString().trim(), key.text.toString())
                key.setText("")
                testProvider(spec.id, savedStatus)
            }
            buttons.addView(test, LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(buttons)
            gap(c, 5)
            actionButton(c, "Pobierz listę modeli z API") {
                store.saveConfig(spec.id, endpoint.text.toString().trim(), model.text.toString().trim(), key.text.toString())
                key.setText("")
                val saved = store.loadConfig(spec.id)
                if (saved == null || saved.apiKey.isBlank()) {
                    Toast.makeText(this, "Najpierw zapisz klucz API", Toast.LENGTH_LONG).show()
                } else {
                    savedStatus.text = "Pobieranie listy modeli…"
                    worker.execute {
                        try {
                            val available = AiApi.listModels(saved)
                            main.post {
                                if (available.isEmpty()) {
                                    savedStatus.text = "API nie zwróciło listy modeli. Wpisz model ręcznie."
                                } else {
                                    AlertDialog.Builder(this).setTitle("Wybierz model — ${spec.title}")
                                        .setItems(available.toTypedArray()) { _, index ->
                                            model.setText(available[index])
                                            store.saveConfig(spec.id, endpoint.text.toString().trim(), available[index], "")
                                            savedStatus.text = "Wybrany model: ${available[index]}"
                                        }.setNegativeButton("Anuluj", null).show()
                                    savedStatus.text = "Pobrano ${available.size} modeli."
                                }
                            }
                        } catch (e: Exception) {
                            main.post { savedStatus.text = "Nie udało się pobrać modeli: ${e.message}" }
                        }
                    }
                }
            }
            gap(c, 5)
            val removeKey = smallButton("Usuń zapisany klucz API") {
                AlertDialog.Builder(this).setTitle("Usunąć klucz ${spec.title}?")
                    .setMessage("Klucz zostanie usunięty z pamięci tego telefonu.")
                    .setNegativeButton("Anuluj", null)
                    .setPositiveButton("Usuń") { _, _ ->
                        store.clearKey(spec.id)
                        savedStatus.text = "○ Brak klucza"
                        savedStatus.setTextColor(Color.rgb(235, 181, 117))
                        Toast.makeText(this, "Usunięto klucz ${spec.title}", Toast.LENGTH_SHORT).show()
                    }.show()
            }
            c.addView(removeKey)
        }
        val webCard = card(body)
        addLabel(webCard, "Strony WWW (bez klucza API)", 15f, Color.WHITE, true)
        addLabel(webCard, "Możesz otworzyć oficjalne czaty w przeglądarce. Nie są one połączone z automatycznym zespołem API.", 12f, Color.rgb(174, 185, 207))
        providers.forEach { p ->
            val url = when (p.id) {
                "gemini" -> "https://gemini.google.com"
                "groq" -> "https://console.groq.com"
                "deepseek" -> "https://chat.deepseek.com"
                "openai" -> "https://chatgpt.com"
                "claude" -> "https://claude.ai"
                else -> "https://grok.com"
            }
            actionButton(webCard, "Otwórz ${p.title}") { openUrl(url) }
        }
    }

    private fun testProvider(id: String, status: TextView) {
        val config = store.loadConfig(id)
        if (config == null || config.apiKey.isBlank()) {
            Toast.makeText(this, "Najpierw zapisz klucz API", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Testowanie połączenia…"
        status.setTextColor(Color.rgb(236, 202, 129))
        worker.execute {
            try {
                val answer = AiApi.chat(config, "Odpowiedz krótko po polsku.", "Napisz tylko: Połączenie działa.")
                main.post {
                    status.text = "✓ API działa: ${answer.take(70)}"
                    status.setTextColor(Color.rgb(119, 220, 165))
                }
            } catch (e: Exception) {
                main.post {
                    status.text = "Błąd API: ${e.message ?: "nieznany błąd"}"
                    status.setTextColor(Color.rgb(255, 133, 133))
                }
            }
        }
    }

    private fun renderHistory() {
        val intro = card(body)
        addLabel(intro, "Historia projektów", 20f, Color.WHITE, true)
        addLabel(intro, "Ostatnie wyniki są zapisywane lokalnie na telefonie.", 12f, Color.rgb(179, 190, 212))
        val history = readHistory()
        if (history.length() == 0) {
            val empty = card(body)
            addLabel(empty, "Brak zapisanych projektów", 14f, Color.rgb(169, 181, 205))
        } else {
            for (i in 0 until history.length()) {
                val item = history.optJSONObject(i) ?: continue
                val c = card(body, 14)
                addLabel(c, item.optString("name", "Projekt"), 15f, Color.WHITE, true)
                addLabel(c, item.optString("date", ""), 10f, Color.rgb(142, 157, 186))
                addLabel(c, item.optString("task", "").take(180), 12f, Color.rgb(176, 188, 210))
                val output = item.optString("output", "")
                actionButton(c, "Otwórz rezultat") { lastTask = item.optString("task", ""); lastOutput = output; renderPage("result") }
            }
        }
        if (history.length() > 0) actionButton(body, "Wyczyść historię") {
            AlertDialog.Builder(this).setTitle("Usunąć historię?").setMessage("Ta operacja usunie zapisane wyniki z tego telefonu.")
                .setNegativeButton("Anuluj", null).setPositiveButton("Usuń") { _, _ -> prefs.edit().remove("history").apply(); renderPage("history") }.show()
        }
    }

    private fun renderLinks() {
        val c = card(body)
        addLabel(c, "Narzędzia i usługi", 20f, Color.WHITE, true)
        addLabel(c, "Szybkie przejścia do stron, na których możesz utworzyć klucze API, boty i wdrożenia. Aplikacja nie loguje się za Ciebie i nie przechowuje haseł.", 12f, Color.rgb(180, 191, 213))
        listOf(
            "Google AI Studio — Gemini API" to "https://aistudio.google.com/apikey",
            "Groq Console — API keys" to "https://console.groq.com/keys",
            "DeepSeek — API platform" to "https://platform.deepseek.com/api_keys",
            "OpenAI — API keys" to "https://platform.openai.com/api-keys",
            "Anthropic Console — API keys" to "https://console.anthropic.com/settings/keys",
            "xAI Console — API keys" to "https://console.x.ai/",
            "Discord Developer Portal" to "https://discord.com/developers/applications",
            "GitHub" to "https://github.com/"
        ).forEach { (title, url) -> actionButton(c, title) { openUrl(url) } }
    }

    private fun renderResult() {
        val c = card(body)
        addLabel(c, "Rezultat projektu", 20f, Color.WHITE, true)
        addLabel(c, lastTask.take(350), 12f, Color.rgb(172, 185, 209))
        gap(c, 10)
        addLabel(c, lastOutput.ifBlank { "Brak rezultatu." }, 12f, Color.rgb(229, 234, 245))
        gap(c, 12)
        actionButton(c, "Kopiuj rezultat") {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AI Swarm result", lastOutput))
            Toast.makeText(this, "Skopiowano do schowka", Toast.LENGTH_SHORT).show()
        }
        actionButton(c, "Udostępnij rezultat") { shareOutput() }
        actionButton(c, "Zapisz jako plik TXT") { saveOutput() }
        actionButton(c, "Wróć do strony startowej") { renderPage("home") }
    }

    private fun startSwarm() {
        if (busy) return
        val task = taskInput.text.toString().trim()
        if (task.length < 8) {
            Toast.makeText(this, "Opisz zadanie trochę dokładniej.", Toast.LENGTH_LONG).show()
            return
        }
        val configured = providers.mapNotNull { store.loadConfig(it.id) }.filter { it.apiKey.isNotBlank() }
        if (configured.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Brak klucza API")
                .setMessage("Aby uruchomić prawdziwych agentów, zapisz przynajmniej jeden klucz API w zakładce API. Same konta na stronach ChatGPT/Claude nie dają automatycznego dostępu do API.")
                .setNegativeButton("Później", null).setPositiveButton("Otwórz API") { _, _ -> renderPage("providers") }.show()
            return
        }
        lastTask = task
        val projectName = projectInput.text.toString().trim().ifBlank { "Nowy projekt" }
        busy = true
        runButton?.apply { text = "ZESPÓŁ PRACUJE…"; alpha = 0.55f }
        liveStatus?.text = "Uruchamiam Managera…"
        val roleConfigs = agentRoles.associate { role ->
            val saved = prefs.getString("role.${role.first}", providers.first().id) ?: providers.first().id
            val chosen = store.loadConfig(saved)?.takeIf { it.apiKey.isNotBlank() } ?: configured.first()
            role.first to chosen
        }
        worker.execute {
            val result = StringBuilder()
            try {
                val plan = AiApi.chat(roleConfigs.getValue("manager"),
                    "Jesteś Managerem zespołu AI. Odpowiadaj po polsku. Rozbij zadanie na konkretne etapy, wymagania, kryteria ukończenia i ryzyka. Nie twierdź, że wykonałeś czynności, których nie wykonałeś.",
                    "Projekt: $projectName\nZadanie:\n$task\n\nPrzygotuj plan pracy dla zespołu.")
                result.append("# 1. PLAN MANAGERA\n\n").append(plan).append("\n\n")
                updateProgress("Manager zakończył plan. Pracuje Analityk…")

                val research = AiApi.chat(roleConfigs.getValue("research"),
                    "Jesteś analitykiem. Odpowiadasz po polsku. Przeanalizuj plan i zadanie. Wskaż wymagania, założenia, możliwe błędy, ryzyka bezpieczeństwa, zależności i testy. Nie udawaj, że wykonałeś live web search.",
                    "Zadanie:\n$task\n\nPlan Managera:\n$plan\n\nDodatkowa analiza i wymagania dla wykonawcy:")
                result.append("# 2. ANALIZA\n\n").append(research).append("\n\n")
                updateProgress("Analityk zakończył analizę. Builder tworzy rozwiązanie…")

                val build = AiApi.chat(roleConfigs.getValue("builder"),
                    "Jesteś głównym wykonawcą projektu. Twórz konkretny, kompletny rezultat po polsku. Dla programowania dostarczaj pełne pliki, ścieżki, kod i instrukcję uruchomienia. Nie pomijaj istotnych fragmentów kodu i nie używaj wielokropków jako zastępstwa. Nie twierdź, że wdrożyłeś lub uruchomiłeś coś poza tą rozmową.",
                    "Projekt: $projectName\nZadanie:\n$task\n\nPlan:\n$plan\n\nAnaliza:\n$research\n\nWykonaj właściwy rezultat.")
                result.append("# 3. WYKONANIE\n\n").append(build).append("\n\n")
                updateProgress("Builder skończył. Reviewer sprawdza rezultat…")

                val review = AiApi.chat(roleConfigs.getValue("reviewer"),
                    "Jesteś wymagającym recenzentem i testerem. Po polsku sprawdź rezultat pod kątem zgodności z zadaniem, błędów, braków, bezpieczeństwa i wykonalności. Następnie zwróć poprawioną, końcową wersję. Jeśli to kod, popraw kod, a nie tylko opisz błędy. Nie wymyślaj wyników testów.",
                    "Zadanie:\n$task\n\nRezultat Buildera:\n$build\n\nWykonaj przegląd i zwróć finalną, poprawioną wersję.")
                result.append("# 4. REVIEWER — WERSJA KOŃCOWA\n\n").append(review)
                lastOutput = result.toString()
                saveHistory(projectName, task, lastOutput)
                main.post {
                    busy = false
                    renderPage("result")
                    Toast.makeText(this, "Zespół zakończył pracę", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                val partial = result.toString()
                main.post {
                    busy = false
                    runButton?.apply { text = "URUCHOM ZESPÓŁ AI"; alpha = 1f }
                    liveStatus?.text = "Błąd: ${e.message ?: "nieznany błąd"}"
                    liveStatus?.setTextColor(Color.rgb(255, 135, 135))
                    if (partial.isNotBlank()) {
                        lastOutput = partial + "\n\n## BŁĄD\n${e.message}"
                        AlertDialog.Builder(this).setTitle("Zespół przerwał pracę")
                            .setMessage("Częściowy wynik został zachowany.\n\n${e.message}")
                            .setPositiveButton("Pokaż wynik") { _, _ -> renderPage("result") }
                            .setNegativeButton("OK", null).show()
                    } else {
                        Toast.makeText(this, "Nie udało się uruchomić zespołu: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun updateProgress(value: String) {
        main.post { liveStatus?.text = value }
    }

    private fun saveHistory(name: String, task: String, output: String) {
        val list = readHistory()
        val item = JSONObject().put("name", name).put("task", task).put("output", output).put("date", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date()))
        val next = JSONArray().put(item)
        for (i in 0 until minOf(list.length(), 9)) next.put(list.getJSONObject(i))
        prefs.edit().putString("history", next.toString()).apply()
    }

    private fun readHistory(): JSONArray = try { JSONArray(prefs.getString("history", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun shareOutput() {
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "AI Swarm — $lastTask"); putExtra(Intent.EXTRA_TEXT, lastOutput) }
        startActivity(Intent.createChooser(intent, "Udostępnij wynik"))
    }

    private fun saveOutput() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "AI-Swarm-result.txt")
        }
        try { startActivityForResult(intent, 701) } catch (e: Exception) { Toast.makeText(this, "Nie można otworzyć zapisu pliku: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Android, retained for compatibility with minSdk 26")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(lastOutput.toByteArray(StandardCharsets.UTF_8)) }
                Toast.makeText(this, "Zapisano plik", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Błąd zapisu: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "Brak aplikacji do otwarcia linku", Toast.LENGTH_SHORT).show() }
    }
}

private class SecureStore(context: Context) {
    private val prefs = context.getSharedPreferences("aiswarm_secure", Context.MODE_PRIVATE)
    private val alias = "aiswarm_api_key_aes"
    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        if (value.isBlank()) return ""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        if (value.isBlank()) return ""
        return try {
            val all = Base64.decode(value, Base64.NO_WRAP)
            val iv = all.copyOfRange(0, 12)
            val cipherText = all.copyOfRange(12, all.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherText), StandardCharsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun saveConfig(id: String, endpoint: String, model: String, newKey: String) {
        val oldKey = prefs.getString("$id.key", "") ?: ""
        val editor = prefs.edit()
            .putString("$id.endpoint", endpoint)
            .putString("$id.model", model)
        if (newKey.isNotBlank()) editor.putString("$id.key", encrypt(newKey.trim()))
        else if (oldKey.isNotBlank()) editor.putString("$id.key", oldKey)
        editor.apply()
    }

    fun loadConfig(id: String): ProviderConfig? {
        val spec = providerList.firstOrNull { it.id == id } ?: return null
        val endpoint = prefs.getString("$id.endpoint", spec.endpoint) ?: spec.endpoint
        val model = prefs.getString("$id.model", spec.model) ?: spec.model
        val encrypted = prefs.getString("$id.key", "") ?: ""
        return ProviderConfig(spec, endpoint, model, decrypt(encrypted))
    }

    fun clearKey(id: String) { prefs.edit().remove("$id.key").apply() }

    companion object {
        private val providerList = listOf(
            ProviderSpec("gemini", "Google Gemini", "gemini", "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", "gemini-3.8-flash", ""),
            ProviderSpec("groq", "Groq", "openai", "https://api.groq.com/openai/v1/chat/completions", "openai/gpt-oss-120b", ""),
            ProviderSpec("deepseek", "DeepSeek", "openai", "https://api.deepseek.com/chat/completions", "deepseek-flash", ""),
            ProviderSpec("openai", "OpenAI", "openai", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", ""),
            ProviderSpec("claude", "Anthropic Claude", "anthropic", "https://api.anthropic.com/v1/messages", "claude-haiku-4-5-20251001", ""),
            ProviderSpec("grok", "xAI Grok", "openai", "https://api.x.ai/v1/chat/completions", "grok-4.7", "")
        )
    }
}

private object AiApi {
    fun listModels(config: ProviderConfig): List<String> {
        if (config.apiKey.isBlank()) throw IllegalStateException("Brak klucza API")
        val endpoint = when (config.spec.kind) {
            "gemini" -> config.endpoint.substringBefore("/models/").trimEnd('/') + "/models"
            "anthropic" -> config.endpoint.replace(Regex("/messages/?$"), "/models")
            else -> if (config.endpoint.matches(Regex(".*?/chat/completions/?$"))) {
                config.endpoint.replace(Regex("/chat/completions/?$"), "/models")
            } else {
                config.endpoint.trimEnd('/') + "/models"
            }
        }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 45_000
            setRequestProperty("Accept", "application/json")
            when (config.spec.kind) {
                "anthropic" -> {
                    setRequestProperty("x-api-key", config.apiKey)
                    setRequestProperty("anthropic-version", "2023-06-01")
                }
                "gemini" -> setRequestProperty("x-goog-api-key", config.apiKey)
                else -> setRequestProperty("Authorization", "Bearer ${config.apiKey}")
            }
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299) {
                val error = json.optJSONObject("error")?.optString("message") ?: text.take(300)
                throw IllegalStateException("${config.spec.title}: HTTP $code — $error")
            }
            val array = when (config.spec.kind) {
                "gemini" -> json.optJSONArray("models") ?: JSONArray()
                else -> json.optJSONArray("data") ?: JSONArray()
            }
            val names = ArrayList<String>()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                if (config.spec.kind == "gemini") {
                    val methods = item.optJSONArray("supportedGenerationMethods")
                    if (methods != null && (0 until methods.length()).none { methods.optString(it) == "generateContent" }) continue
                }
                val name = if (config.spec.kind == "gemini") item.optString("name").removePrefix("models/") else item.optString("id")
                if (name.isNotBlank() && name != "null") names.add(name)
            }
            return names.distinct().sorted()
        } finally {
            connection.disconnect()
        }
    }

    fun chat(config: ProviderConfig, system: String, prompt: String): String {
        if (config.apiKey.isBlank()) throw IllegalStateException("Brak klucza API dla ${config.spec.title}")
        val endpoint = when (config.spec.kind) {
            "gemini" -> config.endpoint.replace("{model}", URLEncoder.encode(config.model, "UTF-8"))
            else -> config.endpoint
        }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 25_000
            readTimeout = 150_000
            doOutput = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        if (config.spec.kind == "gemini") connection.setRequestProperty("x-goog-api-key", config.apiKey)
        val payload = when (config.spec.kind) {
            "anthropic" -> {
                connection.setRequestProperty("x-api-key", config.apiKey)
                connection.setRequestProperty("anthropic-version", "2023-06-01")
                JSONObject().put("model", config.model).put("max_tokens", 4096).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            }
            "gemini" -> JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.35).put("maxOutputTokens", 4096))
            else -> {
                connection.setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                JSONObject().put("model", config.model).put("temperature", 0.35)
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", system))
                        .put(JSONObject().put("role", "user").put("content", prompt)))
            }
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299) {
                val message = json.optJSONObject("error")?.optString("message")
                    ?: json.optString("message").takeIf { it.isNotBlank() }
                    ?: responseText.take(350).ifBlank { "HTTP $code" }
                throw IllegalStateException("${config.spec.title}: HTTP $code — $message")
            }
            val answer = when (config.spec.kind) {
                "anthropic" -> {
                    val content = json.optJSONArray("content") ?: JSONArray()
                    (0 until content.length()).mapNotNull { content.optJSONObject(it)?.optString("text") }.joinToString("\n")
                }
                "gemini" -> {
                    val candidates = json.optJSONArray("candidates") ?: JSONArray()
                    val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                    (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text") }.joinToString("\n")
                }
                else -> {
                    val choices = json.optJSONArray("choices") ?: JSONArray()
                    val content = choices.optJSONObject(0)?.optJSONObject("message")?.opt("content")
                    when (content) {
                        is String -> content
                        is JSONArray -> (0 until content.length()).mapNotNull { content.optJSONObject(it)?.optString("text") }.joinToString("\n")
                        else -> ""
                    }
                }
            }
            if (answer.isBlank()) throw IllegalStateException("${config.spec.title}: API zwróciło pustą odpowiedź lub nieznany format.")
            return answer
        } finally {
            connection.disconnect()
        }
    }
}
