# AI Swarm Mobile 1.0

Native Android application with a four-stage AI workflow: Manager → Analyst → Builder → Reviewer.

## What works

- Native Android interface in Polish (no placeholder WebView screen).
- Configure Gemini, Groq, DeepSeek, OpenAI, Anthropic Claude and xAI Grok API endpoints, models and API keys.
- API keys are encrypted on-device using Android Keystore (AES-GCM). Passwords and browser cookies are not collected.
- Run a sequential four-agent workflow. Each agent receives the previous stage's result.
- Choose a provider per agent. If one selected provider is not configured, the app falls back to the first provider with a saved API key.
- Test API connections and fetch model lists from provider APIs in the settings page.
- Save the latest ten project results locally, then open, copy, share or export them as a text file.
- Quick-start prompts for websites and Discord bots.
- Shortcuts to provider consoles and official chat websites.

## Important limits

- The app calls provider APIs. A ChatGPT/Claude/Gemini website login is not an API key and cannot be used as an API credential.
- API providers have their own quotas, model availability and pricing. A free quota is not guaranteed and can change.
- The Research role analyses the prompt and supplied context; it does not claim to perform live web search.
- The app generates code and instructions. It does not automatically host a website, deploy a Discord bot or run code on a remote server.
- The app does not rotate accounts or bypass provider rate limits, CAPTCHAs, security controls or plan limits.

## Build APK with GitHub Actions

The workflow is located at `.github/workflows/build.yml`.

1. Push the complete project folder contents into the root of the GitHub repository (not the ZIP file itself).
2. Open **Actions** → **Build AI Swarm Mobile APK**.
3. Press **Run workflow** on the default branch.
4. Wait for the job to finish successfully.
5. Download `AI-Swarm-Mobile-APK` under **Artifacts**. A manual workflow run also publishes `app-debug.apk` as a downloadable asset in a GitHub Release.

The workflow runs for pushes to any branch and can also be started manually. It explicitly installs Android SDK 35, uses JDK 17 and Gradle 8.9, runs `gradle clean assembleDebug`, verifies that the APK exists, and then uploads it. A manual run also creates a GitHub Release with the APK attached. It does not depend on a missing Gradle Wrapper.

## Build locally

Open the project root in Android Studio, install Android SDK Platform 35 and JDK 17, then run the Gradle task `:app:assembleDebug`.
